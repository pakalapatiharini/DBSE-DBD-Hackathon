# Frontend — React (Vite) (Phase 3)

**ParkGrid** — the Smart Parking Management System UI · CODESPARK Hackathon 2026 · Problem #01

React 18 + Vite 5 + React Router 6, plain JavaScript, hand-rolled CSS (no UI framework). The frontend talks **only** to the Spring Boot backend (`http://localhost:8080`) — never to MySQL or the Python service directly.

## Run

Prerequisites: Node 18+ and the backend running (see `../backend/README.md` — the `dev` profile is the fastest way).

```bash
cd frontend
npm install
npm run dev
```

App URL: **http://localhost:5173** (the backend's CORS is configured for exactly this origin).

Production build check:

```bash
npm run build
```

### Configuration

| Env var | Default | Notes |
|---|---|---|
| `VITE_API_BASE_URL` | `http://localhost:8080` | Backend base URL. Copy `.env.example` to `.env` to override. |

## Demo accounts (seeded by the backend)

| Role | Email | Password |
|---|---|---|
| USER | `user1@example.com` | `user123` |
| USER | `user2@example.com` | `user123` |
| ADMIN | `admin@smartparking.local` | `admin123` |

The login screen also has one-click demo fill buttons.

## Pages

| Route | Who | What |
|---|---|---|
| `/login`, `/register` | Public | JWT login; registration always creates a USER. Session is kept in `localStorage`; any `401` from the API auto-logs-out to `/login`. |
| `/` | USER, ADMIN | Location cards with hourly rate and live available/reserved/occupied counts. |
| `/locations/:id` | USER, ADMIN | **Slot map** — slots grouped by vehicle type, tiles colour-coded by live derived status (green AVAILABLE / amber RESERVED / red OCCUPIED), auto-refresh every 15 s + manual Refresh. Clicking a slot opens the booking panel: window pickers re-check the backend availability endpoint, fee is estimated with the backend rule (ceil hours, min 1, × rate), vehicles can be added inline, and a backend `409` overlap is shown as a clear "slot just got booked" message. Includes the compact prediction panel (hourly occupancy + peak-hour callout). |
| `/vehicles` | USER | My Vehicles — list, add, delete. |
| `/reservations` | USER | My Reservations — status filters, Cancel / Entry / Exit actions per status. |
| `/admin` | ADMIN | Dashboard stat tiles from `GET /api/admin/dashboard` + compact prediction chart per location. |
| `/admin/locations` | ADMIN | Create/edit/delete locations; add/delete/activate/deactivate slots per location. |
| `/admin/reservations` | ADMIN | All reservations with location / status / date filters. |

Notes:

- Booking and vehicle management are **USER-role endpoints on the backend**, so those nav items are shown to users; admins get the admin views instead. Signed in as ADMIN, the slot-map booking panel explains this rather than failing.
- Slot status is **derived on the backend** from reservations — the UI never stores or invents it.
- Design: asphalt/ink neutrals with a road-marking yellow accent and a green/amber/red status system that matches the slot tiles; Archivo display type + Inter body. No icon fonts/emoji — the logo is inline SVG.
