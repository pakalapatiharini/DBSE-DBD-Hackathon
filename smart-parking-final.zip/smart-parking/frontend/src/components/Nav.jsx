import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AppContext';

function LogoMark() {
  return (
    <svg width="30" height="30" viewBox="0 0 32 32" aria-hidden="true">
      <rect width="32" height="32" rx="7" fill="#f2c230" />
      <path d="M11 24V8h6.2a5.4 5.4 0 0 1 0 10.8H14V24h-3zm3-8.4h3a2.6 2.6 0 0 0 0-5.2h-3v5.2z" fill="#16191d" />
    </svg>
  );
}

export default function Nav() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const isAdmin = user?.role === 'ADMIN';

  const onLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <header className="topnav">
      <div className="topnav-inner">
        <NavLink to="/" className="brand">
          <LogoMark />
          <span className="brand-name">PARK<em>GRID</em></span>
        </NavLink>
        <nav className="topnav-links">
          <NavLink to="/" end>Locations</NavLink>
          {!isAdmin && <NavLink to="/reservations">My Reservations</NavLink>}
          {!isAdmin && <NavLink to="/vehicles">My Vehicles</NavLink>}
          {isAdmin && <NavLink to="/admin">Dashboard</NavLink>}
          {isAdmin && <NavLink to="/admin/locations">Manage Locations</NavLink>}
          {isAdmin && <NavLink to="/admin/reservations">All Reservations</NavLink>}
        </nav>
        <div className="topnav-user">
          <div className="user-chip">
            <span className="user-avatar">{(user?.fullName || '?').trim().charAt(0).toUpperCase()}</span>
            <span className="user-meta">
              <span className="user-name">{user?.fullName}</span>
              <span className={`user-role role-${(user?.role || '').toLowerCase()}`}>{user?.role}</span>
            </span>
          </div>
          <button className="btn btn-ghost btn-sm" onClick={onLogout}>Logout</button>
        </div>
      </div>
    </header>
  );
}
