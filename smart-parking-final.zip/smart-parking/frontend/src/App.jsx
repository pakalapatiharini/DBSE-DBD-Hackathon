import { Navigate, Outlet, Route, Routes, useLocation } from 'react-router-dom';
import { useAuth } from './context/AppContext';
import Nav from './components/Nav';
import Login from './pages/Login';
import Register from './pages/Register';
import Locations from './pages/Locations';
import LocationDetail from './pages/LocationDetail';
import Vehicles from './pages/Vehicles';
import Reservations from './pages/Reservations';
import AdminDashboard from './pages/AdminDashboard';
import AdminLocations from './pages/AdminLocations';
import AdminReservations from './pages/AdminReservations';

function RequireAuth() {
  const { user } = useAuth();
  const location = useLocation();
  if (!user) return <Navigate to="/login" replace state={{ from: location.pathname }} />;
  return (
    <>
      <Nav />
      <main className="shell">
        <Outlet />
      </main>
      <footer className="footer">ParkGrid — Smart Parking Management System · CODESPARK Hackathon 2026</footer>
    </>
  );
}

function RequireRole({ role, children }) {
  const { user } = useAuth();
  if (user?.role !== role) return <Navigate to="/" replace />;
  return children;
}

function GuestOnly({ children }) {
  const { user } = useAuth();
  if (user) return <Navigate to="/" replace />;
  return children;
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<GuestOnly><Login /></GuestOnly>} />
      <Route path="/register" element={<GuestOnly><Register /></GuestOnly>} />
      <Route element={<RequireAuth />}>
        <Route path="/" element={<Locations />} />
        <Route path="/locations/:id" element={<LocationDetail />} />
        <Route path="/vehicles" element={<RequireRole role="USER"><Vehicles /></RequireRole>} />
        <Route path="/reservations" element={<RequireRole role="USER"><Reservations /></RequireRole>} />
        <Route path="/admin" element={<RequireRole role="ADMIN"><AdminDashboard /></RequireRole>} />
        <Route path="/admin/locations" element={<RequireRole role="ADMIN"><AdminLocations /></RequireRole>} />
        <Route path="/admin/reservations" element={<RequireRole role="ADMIN"><AdminReservations /></RequireRole>} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
