import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../lib/api';
import { useToast } from '../context/AppContext';
import { fmtDateTime, inr } from '../lib/format';

const FILTERS = ['', 'RESERVED', 'OCCUPIED', 'COMPLETED', 'CANCELLED'];

export function StatusChip({ status }) {
  return <span className={`chip chip-${status.toLowerCase()}`}>{status}</span>;
}

export default function Reservations() {
  const toast = useToast();
  const [items, setItems] = useState([]);
  const [filter, setFilter] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [acting, setActing] = useState(null);

  const load = async () => {
    try {
      setItems(await api.myReservations(filter || undefined));
      setError('');
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { setLoading(true); load(); }, [filter]);

  const act = async (r, action) => {
    setActing(r.id + action);
    try {
      const fn = { cancel: api.cancelReservation, entry: api.entryReservation, exit: api.exitReservation }[action];
      const updated = await fn(r.id);
      toast(`Reservation #${r.id} is now ${updated.status}`);
      await load();
    } catch (e) {
      toast(e.message, 'error');
    } finally {
      setActing(null);
    }
  };

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <h2>My reservations</h2>
          <p className="muted">Check in when you arrive, check out when you leave.</p>
        </div>
        <div className="filter-row">
          {FILTERS.map((f) => (
            <button key={f || 'ALL'} className={`filter-chip ${filter === f ? 'is-active' : ''}`} onClick={() => setFilter(f)}>
              {f || 'All'}
            </button>
          ))}
        </div>
      </div>

      {error && <div className="alert alert-error">{error}</div>}
      {loading && <p className="muted">Loading reservations…</p>}
      {!loading && items.length === 0 && (
        <div className="panel empty-state">
          No reservations{filter ? ` with status ${filter}` : ''} yet. <Link to="/">Find a parking location</Link> to make your first booking.
        </div>
      )}

      <div className="card-list">
        {items.map((r) => (
          <div key={r.id} className="panel reservation-card">
            <div className="reservation-main">
              <div className="reservation-title">
                <strong>{r.locationName}</strong>
                <span className="slot-badge">Slot {r.slotCode}</span>
                <StatusChip status={r.status} />
              </div>
              <p className="muted small">
                {r.licensePlate} · {fmtDateTime(r.startTime)} → {fmtDateTime(r.endTime)}
              </p>
              <p className="muted small">
                Fee <strong className="ink">{inr(r.feeAmount)}</strong>
                {r.entryTime ? ` · Entered ${fmtDateTime(r.entryTime)}` : ''}
                {r.exitTime ? ` · Exited ${fmtDateTime(r.exitTime)}` : ''}
              </p>
            </div>
            <div className="reservation-actions">
              {r.status === 'RESERVED' && (
                <>
                  <button className="btn btn-dark btn-sm" disabled={acting !== null} onClick={() => act(r, 'entry')}>
                    {acting === r.id + 'entry' ? '…' : 'Entry — I have arrived'}
                  </button>
                  <button className="btn btn-danger-ghost btn-sm" disabled={acting !== null} onClick={() => act(r, 'cancel')}>
                    {acting === r.id + 'cancel' ? '…' : 'Cancel'}
                  </button>
                </>
              )}
              {r.status === 'OCCUPIED' && (
                <button className="btn btn-primary btn-sm" disabled={acting !== null} onClick={() => act(r, 'exit')}>
                  {acting === r.id + 'exit' ? '…' : 'Exit — Check out'}
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
