import { useEffect, useState } from 'react';
import { api } from '../lib/api';
import { useToast } from '../context/AppContext';
import { VEHICLE_TYPES, VEHICLE_TYPE_LABELS, fmtDateTime } from '../lib/format';

export default function Vehicles() {
  const toast = useToast();
  const [vehicles, setVehicles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [form, setForm] = useState({ licensePlate: '', vehicleType: 'FOUR_WHEELER', model: '', color: '' });
  const [busy, setBusy] = useState(false);

  const load = async () => {
    try {
      setVehicles(await api.myVehicles());
      setError('');
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      const v = await api.createVehicle({
        licensePlate: form.licensePlate.trim().toUpperCase(),
        vehicleType: form.vehicleType,
        model: form.model.trim() || undefined,
        color: form.color.trim() || undefined,
      });
      toast(`Vehicle ${v.licensePlate} added`);
      setForm({ licensePlate: '', vehicleType: 'FOUR_WHEELER', model: '', color: '' });
      await load();
    } catch (err) {
      toast(err.message, 'error');
    } finally {
      setBusy(false);
    }
  };

  const remove = async (v) => {
    if (!window.confirm(`Delete vehicle ${v.licensePlate}?`)) return;
    try {
      await api.deleteVehicle(v.id);
      toast(`Vehicle ${v.licensePlate} deleted`);
      await load();
    } catch (err) {
      toast(err.message, 'error');
    }
  };

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <h2>My vehicles</h2>
          <p className="muted">Vehicles you can book parking for.</p>
        </div>
      </div>

      {error && <div className="alert alert-error">{error}</div>}

      <div className="two-col">
        <section className="panel">
          <h3>Add a vehicle</h3>
          <form onSubmit={submit} className="form">
            <label>
              License plate
              <input required value={form.licensePlate} onChange={set('licensePlate')} placeholder="TS09AB1234" />
            </label>
            <label>
              Type
              <select value={form.vehicleType} onChange={set('vehicleType')}>
                {VEHICLE_TYPES.map((t) => <option key={t} value={t}>{VEHICLE_TYPE_LABELS[t]}</option>)}
              </select>
            </label>
            <label>
              Model <span className="optional">(optional)</span>
              <input value={form.model} onChange={set('model')} placeholder="Hyundai Creta" />
            </label>
            <label>
              Colour <span className="optional">(optional)</span>
              <input value={form.color} onChange={set('color')} placeholder="White" />
            </label>
            <button className="btn btn-primary" disabled={busy}>{busy ? 'Adding…' : 'Add vehicle'}</button>
          </form>
        </section>

        <section>
          {loading && <p className="muted">Loading vehicles…</p>}
          {!loading && vehicles.length === 0 && (
            <div className="panel empty-state">No vehicles yet. Add your first one to start booking.</div>
          )}
          <div className="card-list">
            {vehicles.map((v) => (
              <div key={v.id} className="panel vehicle-card">
                <div>
                  <span className="plate">{v.licensePlate}</span>
                  <p className="muted small">
                    {VEHICLE_TYPE_LABELS[v.vehicleType] || v.vehicleType}
                    {v.model ? ` · ${v.model}` : ''}{v.color ? ` · ${v.color}` : ''}
                  </p>
                  <p className="muted small">Added {fmtDateTime(v.createdAt)}</p>
                </div>
                <button className="btn btn-danger-ghost btn-sm" onClick={() => remove(v)}>Delete</button>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
