import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { api } from '../lib/api';
import { useAuth, useToast } from '../context/AppContext';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const { login } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  const from = location.state?.from || '/';
  const notice = location.state?.notice;

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      const data = await api.login({ email, password });
      login(data.token, data.user);
      toast(`Welcome back, ${data.user.fullName}`);
      navigate(from, { replace: true });
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  const fillDemo = (demoEmail, demoPassword) => {
    setEmail(demoEmail);
    setPassword(demoPassword);
    setError('');
  };

  return (
    <div className="auth-wrap">
      <div className="auth-card">
        <div className="auth-brand">
          <svg width="38" height="38" viewBox="0 0 32 32" aria-hidden="true">
            <rect width="32" height="32" rx="7" fill="#f2c230" />
            <path d="M11 24V8h6.2a5.4 5.4 0 0 1 0 10.8H14V24h-3zm3-8.4h3a2.6 2.6 0 0 0 0-5.2h-3v5.2z" fill="#16191d" />
          </svg>
          <h1>PARK<em>GRID</em></h1>
          <p>Find a slot. Book it. Park.</p>
        </div>

        {notice && <div className="alert alert-success">{notice}</div>}
        {error && <div className="alert alert-error">{error}</div>}

        <form onSubmit={submit} className="form">
          <label>
            Email
            <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" autoComplete="email" />
          </label>
          <label>
            Password
            <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Your password" autoComplete="current-password" />
          </label>
          <button className="btn btn-primary btn-block" disabled={busy}>{busy ? 'Signing in…' : 'Sign in'}</button>
        </form>

        <p className="auth-alt">New here? <Link to="/register">Create an account</Link></p>

        <div className="demo-box">
          <span className="demo-title">Demo accounts — click to fill</span>
          <button type="button" className="demo-chip" onClick={() => fillDemo('user1@example.com', 'user123')}>
            User · user1@example.com / user123
          </button>
          <button type="button" className="demo-chip" onClick={() => fillDemo('admin@smartparking.local', 'admin123')}>
            Admin · admin@smartparking.local / admin123
          </button>
        </div>
      </div>
    </div>
  );
}
