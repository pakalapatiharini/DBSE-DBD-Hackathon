import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { api } from '../lib/api';
import { useAuth, useToast } from '../context/AppContext';
import PredictionPanel from '../components/PredictionPanel';
import {
  VEHICLE_TYPES, VEHICLE_TYPE_LABELS, defaultWindow, estimateFee,
  inr, toIso,
} from '../lib/format';

const TYPE_ORDER = ['FOUR_WHEELER', 'TWO_WHEELER', 'EV', 'ACCESSIBLE', 'GENERAL'];

export default function LocationDetail() {
  const { id } = useParams();
  const locationId = Number(id);
  const { user } = useAuth();
  const isAdmin = user?.role === 'ADMIN';
  const toast = useToast();
  const navigate = useNavigate();

  const [location, setLocation] = useState(null);
  const [slots, setSlots] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [lastUpdated, setLastUpdated] = useState(null);

  const [selected, setSelected] = useState(null); // slot object
  const [win, setWin] = useState(defaultWindow); // {start, end} datetime-local strings
  const [windowSlotIds, setWindowSlotIds] = useState(null); // Set of slot ids free in window
  const [windowError, setWindowError] = useState('');

  const [vehicles, setVehicles] = useState([]);
  const [vehicleId, setVehicleId] = useState('');
  const [showAddVehicle, setShowAddVehicle] = useState(false);
  const [newVehicle, setNewVehicle] = useState({ licensePlate: '', vehicleType: 'FOUR_WHEELER', model: '', color: '' });

  const [booking, setBooking] = useState(false);
  const [bookError, setBookError] = useState('');
  const [conflict, setConflict] = useState(false);

  const timerRef = useRef(null);

  const loadSlots = useCallback(async (quiet = false) => {
    try {
      const data = await api.slotsByLocation(locationId);
      setSlots(data);
      setLastUpdated(new Date());
      setSelected((prev) => (prev ? data.find((s) => s.id === prev.id) || prev : prev));
    } catch (e) {
      if (!quiet) setError(e.message);
    }
  }, [locationId]);

  // Initial load: location + slots (+ my vehicles for USER)
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const loc = await api.location(locationId);
        if (!cancelled) setLocation(loc);
      } catch (e) {
        if (!cancelled) setError(e.message);
      }
      await loadSlots();
      if (!cancelled) setLoading(false);
      if (!isAdmin) {
        try {
          const vs = await api.myVehicles();
          if (!cancelled) {
            setVehicles(vs);
            if (vs.length) setVehicleId(String(vs[0].id));
          }
        } catch { /* surfaced later in the panel if needed */ }
      }
    })();
    return () => { cancelled = true; };
  }, [locationId, isAdmin, loadSlots]);

  // Auto-refresh the grid every 15s
  useEffect(() => {
    timerRef.current = setInterval(() => loadSlots(true), 15000);
    return () => clearInterval(timerRef.current);
  }, [loadSlots]);

  // Re-check availability whenever the booking window changes
  useEffect(() => {
    if (!win.start || !win.end || win.end <= win.start) {
      setWindowSlotIds(null);
      setWindowError(win.end && win.start && win.end <= win.start ? 'End time must be after start time.' : '');
      return;
    }
    let cancelled = false;
    setWindowError('');
    api.availability(locationId, toIso(win.start), toIso(win.end))
      .then((list) => { if (!cancelled) setWindowSlotIds(new Set(list.map((s) => s.id))); })
      .catch((e) => { if (!cancelled) { setWindowSlotIds(null); setWindowError(e.message); } });
    return () => { cancelled = true; };
  }, [locationId, win.start, win.end]);

  const grouped = useMemo(() => {
    const groups = new Map();
    for (const s of slots) {
      if (!groups.has(s.vehicleType)) groups.set(s.vehicleType, []);
      groups.get(s.vehicleType).push(s);
    }
    return TYPE_ORDER.filter((t) => groups.has(t)).map((t) => ({ type: t, slots: groups.get(t) }));
  }, [slots]);

  const counts = useMemo(() => {
    const c = { AVAILABLE: 0, RESERVED: 0, OCCUPIED: 0 };
    for (const s of slots) if (s.isActive !== false && c[s.status] !== undefined) c[s.status] += 1;
    return c;
  }, [slots]);

  const fee = location ? estimateFee(win.start, win.end, location.hourlyRate) : null;
  const selectedFreeInWindow = !selected || !windowSlotIds || windowSlotIds.has(selected.id);

  const pickSlot = (slot) => {
    setBookError('');
    setConflict(false);
    if (slot.status !== 'AVAILABLE') {
      setSelected(slot);
      return;
    }
    setSelected(slot);
  };

  const addVehicle = async (e) => {
    e.preventDefault();
    try {
      const v = await api.createVehicle({
        licensePlate: newVehicle.licensePlate.trim().toUpperCase(),
        vehicleType: newVehicle.vehicleType,
        model: newVehicle.model.trim() || undefined,
        color: newVehicle.color.trim() || undefined,
      });
      setVehicles((vs) => [...vs, v]);
      setVehicleId(String(v.id));
      setShowAddVehicle(false);
      setNewVehicle({ licensePlate: '', vehicleType: 'FOUR_WHEELER', model: '', color: '' });
      toast(`Vehicle ${v.licensePlate} added`);
    } catch (err) {
      toast(err.message, 'error');
    }
  };

  const book = async (e) => {
    e.preventDefault();
    if (!selected) return;
    if (!vehicleId) { setBookError('Add or select a vehicle first.'); return; }
    setBooking(true);
    setBookError('');
    setConflict(false);
    try {
      const res = await api.createReservation({
        vehicleId: Number(vehicleId),
        slotId: selected.id,
        startTime: toIso(win.start),
        endTime: toIso(win.end),
      });
      toast(`Booked slot ${res.slotCode} at ${res.locationName} — ${inr(res.feeAmount)}`);
      navigate('/reservations');
    } catch (err) {
      if (err.status === 409) {
        setConflict(true);
        setBookError(err.message);
        loadSlots(true);
      } else {
        setBookError(err.message);
      }
    } finally {
      setBooking(false);
    }
  };

  return (
    <div className="page">
      <Link to="/" className="back-link">← All locations</Link>
      {location && (
        <div className="page-head">
          <div>
            <h2>{location.name}</h2>
            <p className="muted">{location.address}{location.city ? `, ${location.city}` : ''} · {inr(location.hourlyRate)}/hr</p>
          </div>
          <div className="head-actions">
            <span className="muted small">{lastUpdated ? `Updated ${lastUpdated.toLocaleTimeString('en-IN')}` : ''}</span>
            <button className="btn btn-ghost btn-sm" onClick={() => loadSlots()}>Refresh</button>
          </div>
        </div>
      )}

      {error && <div className="alert alert-error">{error}</div>}
      {loading && <p className="muted">Loading slot map…</p>}

      {!loading && (
        <div className="detail-layout">
          <div className="detail-main">
            <div className="legend panel-flat">
              <span><i className="dot dot-available" />Available · {counts.AVAILABLE}</span>
              <span><i className="dot dot-reserved" />Reserved · {counts.RESERVED}</span>
              <span><i className="dot dot-occupied" />Occupied · {counts.OCCUPIED}</span>
              <span className="legend-note">Status is live — derived from current reservations</span>
            </div>

            {grouped.map(({ type, slots: groupSlots }) => (
              <section key={type} className="slot-section">
                <h3 className="slot-section-title">{VEHICLE_TYPE_LABELS[type] || type}</h3>
                <div className="slot-grid">
                  {groupSlots.map((slot) => {
                    const bookedInWindow = windowSlotIds && slot.status === 'AVAILABLE' && !windowSlotIds.has(slot.id);
                    const cls = [
                      'slot-tile',
                      `slot-${slot.status.toLowerCase()}`,
                      selected?.id === slot.id ? 'is-selected' : '',
                      slot.isActive === false ? 'is-inactive' : '',
                    ].join(' ');
                    return (
                      <button
                        key={slot.id}
                        type="button"
                        className={cls}
                        disabled={slot.isActive === false}
                        onClick={() => pickSlot(slot)}
                        title={slot.isActive === false ? 'Inactive' : `${slot.slotCode} — ${slot.status}${bookedInWindow ? ' (booked in selected window)' : ''}`}
                      >
                        <span className="slot-code">{slot.slotCode}</span>
                        <span className="slot-status-text">
                          {slot.isActive === false ? 'INACTIVE' : bookedInWindow ? 'BOOKED*' : slot.status}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </section>
            ))}
            {windowSlotIds && <p className="muted small">* Booked for the window selected in the booking panel, even if free right now.</p>}

            <PredictionPanel locationId={locationId} locationName={location?.name} />
          </div>

          <aside className="booking-panel panel">
            {!selected && (
              <>
                <h3>Book a slot</h3>
                <p className="muted">Click any green (available) slot on the map to start booking. Amber and red slots are already taken right now.</p>
              </>
            )}
            {selected && (
              <>
                <h3>Slot {selected.slotCode}</h3>
                <p className="muted small">{VEHICLE_TYPE_LABELS[selected.vehicleType] || selected.vehicleType} · Now: <strong>{selected.status}</strong></p>

                {isAdmin ? (
                  <div className="alert alert-info">
                    You are signed in as ADMIN. Bookings are made from a driver (USER) account — sign in as
                    user1@example.com / user123 to run the booking flow.
                  </div>
                ) : selected.status !== 'AVAILABLE' ? (
                  <div className="alert alert-info">
                    This slot is {selected.status.toLowerCase()} right now. Pick a green slot, or choose a later
                    window — the map marks slots booked inside your selected window with BOOKED*.
                  </div>
                ) : (
                  <form onSubmit={book} className="form">
                    <label>
                      Start
                      <input type="datetime-local" required value={win.start}
                        onChange={(e) => setWin((w) => ({ ...w, start: e.target.value }))} />
                    </label>
                    <label>
                      End
                      <input type="datetime-local" required value={win.end}
                        onChange={(e) => setWin((w) => ({ ...w, end: e.target.value }))} />
                    </label>
                    {windowError && <div className="alert alert-error">{windowError}</div>}
                    {windowSlotIds && !selectedFreeInWindow && (
                      <div className="alert alert-error">
                        Heads up: slot {selected.slotCode} already has a booking that overlaps this window.
                        Submitting will be rejected — pick another slot or time.
                      </div>
                    )}
                    {fee && (
                      <div className="fee-box">
                        <span>{fee.hours} billable hr{fee.hours > 1 ? 's' : ''} × {inr(location.hourlyRate)}</span>
                        <strong>{inr(fee.fee)}</strong>
                      </div>
                    )}

                    <label>
                      Vehicle
                      <select value={vehicleId} onChange={(e) => setVehicleId(e.target.value)} required>
                        <option value="" disabled>Select a vehicle</option>
                        {vehicles.map((v) => (
                          <option key={v.id} value={v.id}>
                            {v.licensePlate} — {VEHICLE_TYPE_LABELS[v.vehicleType] || v.vehicleType}{v.model ? ` · ${v.model}` : ''}
                          </option>
                        ))}
                      </select>
                    </label>
                    <button type="button" className="btn btn-ghost btn-sm" onClick={() => setShowAddVehicle((s) => !s)}>
                      {showAddVehicle ? 'Hide add-vehicle form' : '+ Add a vehicle'}
                    </button>

                    {bookError && (
                      <div className={`alert ${conflict ? 'alert-conflict' : 'alert-error'}`}>
                        {conflict && <strong>Slot just got booked for that window. </strong>}
                        {bookError}
                      </div>
                    )}
                    <button className="btn btn-primary btn-block" disabled={booking}>
                      {booking ? 'Booking…' : `Book slot ${selected.slotCode}`}
                    </button>
                  </form>
                )}

                {showAddVehicle && !isAdmin && (
                  <form onSubmit={addVehicle} className="form vehicle-mini-form">
                    <label>
                      License plate
                      <input required value={newVehicle.licensePlate}
                        onChange={(e) => setNewVehicle((v) => ({ ...v, licensePlate: e.target.value }))}
                        placeholder="TS09AB1234" />
                    </label>
                    <label>
                      Type
                      <select value={newVehicle.vehicleType}
                        onChange={(e) => setNewVehicle((v) => ({ ...v, vehicleType: e.target.value }))}>
                        {VEHICLE_TYPES.map((t) => <option key={t} value={t}>{VEHICLE_TYPE_LABELS[t]}</option>)}
                      </select>
                    </label>
                    <label>
                      Model <span className="optional">(optional)</span>
                      <input value={newVehicle.model}
                        onChange={(e) => setNewVehicle((v) => ({ ...v, model: e.target.value }))} placeholder="Hyundai Creta" />
                    </label>
                    <label>
                      Colour <span className="optional">(optional)</span>
                      <input value={newVehicle.color}
                        onChange={(e) => setNewVehicle((v) => ({ ...v, color: e.target.value }))} placeholder="White" />
                    </label>
                    <button className="btn btn-dark btn-block">Add vehicle</button>
                  </form>
                )}
              </>
            )}
          </aside>
        </div>
      )}
    </div>
  );
}
