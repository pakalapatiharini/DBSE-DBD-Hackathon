import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../lib/api';

export default function Register() {
  const [form, setForm] = useState({ fullName: '', email: '', password: '', phone: '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const navigate = useNavigate();

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      await api.register({
        fullName: form.fullName.trim(),
        email: form.email.trim(),
        password: form.password,
        phone: form.phone.trim() || undefined,
      });
      navigate('/login', { state: { notice: 'Account created — sign in to continue.' } });
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="auth-wrap">
      <div className="auth-card">
        <div className="auth-brand">
          <svg width="38" height="38" viewBox="0 0 32 32" aria-hidden="true">
            <rect width="32" height="32" rx="7" fill="#f2c230" />
            <path d="M11 24V8h6.2a5.4 5.4 0 0 1 0 10.8H14V24h-3zm3-8.4h3a2.6 2.6 0 0 0 0-5.2h-3v5.2z" fill="#16191d" />
          </svg>
          <h1>PARK<em>GRID</em></h1>
          <p>Create your account</p>
        </div>

        {error && <div className="alert alert-error">{error}</div>}

        <form onSubmit={submit} className="form">
          <label>
            Full name
            <input required value={form.fullName} onChange={set('fullName')} placeholder="Your name" autoComplete="name" />
          </label>
          <label>
            Email
            <input type="email" required value={form.email} onChange={set('email')} placeholder="you@example.com" autoComplete="email" />
          </label>
          <label>
            Password
            <input type="password" required minLength={6} value={form.password} onChange={set('password')} placeholder="At least 6 characters" autoComplete="new-password" />
          </label>
          <label>
            Phone <span className="optional">(optional)</span>
            <input value={form.phone} onChange={set('phone')} placeholder="9876543210" autoComplete="tel" />
          </label>
          <button className="btn btn-primary btn-block" disabled={busy}>{busy ? 'Creating…' : 'Create account'}</button>
        </form>

        <p className="auth-alt">Already have an account? <Link to="/login">Sign in</Link></p>
      </div>
    </div>
  );
}
