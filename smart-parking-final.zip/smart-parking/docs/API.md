# API — Smart Parking Management System

Planned REST API for the Spring Boot backend. **Base URL:** `http://localhost:8080` · All paths below are relative to it. All request/response bodies are JSON.

Field names in responses use the same names as `database/schema.sql`, converted to camelCase (e.g. DB `slot_code` → JSON `slotCode`, DB `start_time` → JSON `startTime`). Table and column names referenced below are the exact names from `database/schema.sql`.

## Conventions

- **Auth:** `POST /api/auth/login` returns a token. Send it on every protected call as `Authorization: Bearer <token>`.
- **Roles:** `Public` = no token needed · `USER` / `ADMIN` = token with that role from `users.role`. "Owner" means the resource's `user_id` equals the logged-in user.
- **Timestamps:** ISO-8601 strings, e.g. `"2026-10-09T09:00:00"`.
- **IDs:** JSON `id` maps to the table's `id` column.
- **Errors:** every error returns the same shape:

```json
{ "timestamp": "2026-10-09T10:15:30", "status": 409, "error": "Conflict", "message": "Slot A-01 is already booked for the selected time window", "path": "/api/reservations" }
```

| HTTP status | Used for |
|---|---|
| 400 Bad Request | Validation failure (e.g. `endTime` not after `startTime`, missing/blank field) |
| 401 Unauthorized | Missing/invalid token, wrong login credentials |
| 403 Forbidden | Logged in but wrong role, or not the owner of the resource |
| 404 Not Found | Location, slot, vehicle, or reservation id does not exist |
| 409 Conflict | Overlapping reservation; illegal status transition (e.g. entry on a CANCELLED reservation); duplicate `email` or `license_plate` |

---

## 1. Auth

### POST /api/auth/register — Public

Request:
```json
{ "fullName": "Kairav Vashi", "email": "kairav@example.com", "password": "secret123", "phone": "9876543210" }
```
Response `201 Created` (`role` is always `USER` for self-registration; ADMIN accounts are seeded/created directly):
```json
{ "id": 1, "fullName": "Kairav Vashi", "email": "kairav@example.com", "phone": "9876543210", "role": "USER", "createdAt": "2026-10-09T08:05:00" }
```
Maps to `users` (`full_name`, `email`, `password_hash` — the hash is never returned, `phone`, `role`, `created_at`).

### POST /api/auth/login — Public

Request:
```json
{ "email": "kairav@example.com", "password": "secret123" }
```
Response `200 OK`:
```json
{ "token": "<jwt>", "user": { "id": 1, "fullName": "Kairav Vashi", "email": "kairav@example.com", "role": "USER" } }
```

### GET /api/auth/me — USER, ADMIN

Response `200 OK`: the current user object (same shape as the register response). `401` if the token is missing/invalid.

---

## 2. Parking Locations — `parking_locations`

Location object:
```json
{ "id": 1, "name": "KL University Main Gate Parking", "address": "Bachupally Campus, Main Gate", "city": "Hyderabad", "hourlyRate": 30.00, "isActive": true, "createdAt": "2026-10-09T08:10:00", "updatedAt": "2026-10-09T08:10:00" }
```

| Method | Path | Role | Notes |
|---|---|---|---|
| GET | `/api/locations` | USER, ADMIN | List all locations; only `is_active = 1` ones for USER |
| GET | `/api/locations/{id}` | USER, ADMIN | One location; `404` if missing |
| POST | `/api/locations` | ADMIN | Create; `201` |
| PUT | `/api/locations/{id}` | ADMIN | Update name/address/city/hourly rate/active flag |
| DELETE | `/api/locations/{id}` | ADMIN | Delete (its slots cascade; blocked with `409` if the location's slots have reservations — deactivate via `isActive` instead) |

Create/update request:
```json
{ "name": "KL University Main Gate Parking", "address": "Bachupally Campus, Main Gate", "city": "Hyderabad", "hourlyRate": 30.00, "isActive": true }
```

---

## 3. Parking Slots — `parking_slots`

Slot object (includes the **derived** live status — there is no status column in the DB):
```json
{ "id": 11, "locationId": 1, "slotCode": "A-01", "vehicleType": "FOUR_WHEELER", "isActive": true, "status": "AVAILABLE" }
```
`status` ∈ `AVAILABLE | RESERVED | OCCUPIED`, derived from `reservations` as defined in `docs/ARCHITECTURE.md` §4. `vehicleType` ∈ `TWO_WHEELER | FOUR_WHEELER | EV | ACCESSIBLE | GENERAL` (DB column `vehicle_type`).

| Method | Path | Role | Notes |
|---|---|---|---|
| GET | `/api/locations/{locationId}/slots` | USER, ADMIN | All slots for a location, each with its live derived `status`. This powers the slot map. |
| GET | `/api/slots/{id}` | USER, ADMIN | One slot with live `status` |
| GET | `/api/slots/availability?locationId={id}&startTime={iso}&endTime={iso}` | USER, ADMIN | Slots of the location with **no overlapping** `RESERVED`/`OCCUPIED` reservation in the given window |
| POST | `/api/locations/{locationId}/slots` | ADMIN | Create a slot under a location; `409` if `slotCode` already exists in that location |
| PUT | `/api/slots/{id}` | ADMIN | Update `slotCode` / `vehicleType` / `isActive` |
| DELETE | `/api/slots/{id}` | ADMIN | Delete; `409` if the slot has reservations (deactivate instead) |

Create/update request:
```json
{ "slotCode": "A-01", "vehicleType": "FOUR_WHEELER", "isActive": true }
```

---

## 4. Vehicles — `vehicles`

Vehicle object:
```json
{ "id": 5, "userId": 1, "licensePlate": "TS09AB1234", "vehicleType": "FOUR_WHEELER", "model": "Hyundai Creta", "color": "White", "createdAt": "2026-10-09T08:20:00", "updatedAt": "2026-10-09T08:20:00" }
```

| Method | Path | Role | Notes |
|---|---|---|---|
| GET | `/api/vehicles/my` | USER | Only the logged-in user's vehicles |
| POST | `/api/vehicles` | USER | Create for the logged-in user; `409` if `licensePlate` already exists |
| GET | `/api/vehicles/{id}` | USER (owner), ADMIN | `403` if a USER asks for someone else's vehicle |
| PUT | `/api/vehicles/{id}` | USER (owner) | Update type/model/colour (plate changes re-checked for uniqueness) |
| DELETE | `/api/vehicles/{id}` | USER (owner) | Delete; `409` if the vehicle has reservations |

Create/update request:
```json
{ "licensePlate": "TS09AB1234", "vehicleType": "FOUR_WHEELER", "model": "Hyundai Creta", "color": "White" }
```

---

## 5. Reservations — `reservations`

Reservation object:
```json
{
  "id": 21, "userId": 1, "vehicleId": 5, "slotId": 11, "locationId": 1,
  "licensePlate": "TS09AB1234", "slotCode": "A-01", "locationName": "KL University Main Gate Parking",
  "startTime": "2026-10-09T09:00:00", "endTime": "2026-10-09T12:00:00",
  "status": "RESERVED", "feeAmount": 90.00,
  "entryTime": null, "exitTime": null,
  "createdAt": "2026-10-09T08:25:00", "updatedAt": "2026-10-09T08:25:00"
}
```
`status` ∈ `RESERVED | OCCUPIED | COMPLETED | CANCELLED` (DB column `status`). `locationId` is a read-only convenience field resolved through the slot's `location_id` — there is no `location_id` column on `reservations`. `licensePlate`, `slotCode`, and `locationName` are likewise read-only display fields joined in for the UI.

| Method | Path | Role | Notes |
|---|---|---|---|
| POST | `/api/reservations` | USER | Create a reservation (flow in `docs/ARCHITECTURE.md` §3) |
| GET | `/api/reservations/my` | USER | The logged-in user's reservations, newest first; optional `?status=` filter |
| GET | `/api/reservations/{id}` | USER (owner), ADMIN | One reservation |
| POST | `/api/reservations/{id}/cancel` | USER (owner), ADMIN | Only from `RESERVED` → `CANCELLED`; otherwise `409` |
| POST | `/api/reservations/{id}/entry` | USER (owner), ADMIN | Only from `RESERVED` → `OCCUPIED`; sets `entryTime` to now |
| POST | `/api/reservations/{id}/exit` | USER (owner), ADMIN | Only from `OCCUPIED` → `COMPLETED`; sets `exitTime` to now and finalises `feeAmount` |
| GET | `/api/reservations?locationId=&status=&date=` | ADMIN | All reservations with optional filters (admin list view) |

Create request:
```json
{ "vehicleId": 5, "slotId": 11, "startTime": "2026-10-09T09:00:00", "endTime": "2026-10-09T12:00:00" }
```
Create response: `201 Created` with the reservation object. `feeAmount` is computed by the backend as billable hours (rounded up, minimum 1) × the location's `hourly_rate` — the client never sends a fee. Overlap with an existing `RESERVED`/`OCCUPIED` reservation on the same slot → `409`.

Entry / exit / cancel take **no request body** and return the updated reservation object.

---

## 6. Admin Dashboard — ADMIN only

### GET /api/admin/dashboard

Response `200 OK`:
```json
{
  "totalLocations": 2,
  "totalSlots": 40,
  "availableSlots": 25,
  "reservedSlots": 9,
  "occupiedSlots": 6,
  "occupancyPercent": 37.5,
  "totalReservationsToday": 14,
  "revenueToday": 1260.00
}
```
Definitions: slot counts cover active slots (`is_active = 1`) with the derived status of §3; `occupancyPercent` = (reserved + occupied) ÷ totalSlots × 100; "today" is the server's current date; `revenueToday` = sum of `fee_amount` for reservations created today whose status is not `CANCELLED`.

---

## 7. Prediction — Python-backed

### GET /api/predictions/occupancy?locationId={id}&date={YYYY-MM-DD} — USER, ADMIN

Exposed by the Spring Boot backend, which calls the Python service internally (`GET http://localhost:8000/predict/occupancy`). The browser never calls Python directly.

Response `200 OK`:
```json
{
  "locationId": 1,
  "locationName": "KL University Main Gate Parking",
  "date": "2026-10-09",
  "peakHour": 17,
  "peakOccupancyPercent": 85.0,
  "hourlyPredictions": [
    { "hour": 8,  "predictedOccupancyPercent": 40.0 },
    { "hour": 9,  "predictedOccupancyPercent": 62.5 },
    { "hour": 17, "predictedOccupancyPercent": 85.0 }
  ]
}
```
If the Python service is unreachable (or returns a non-200 / unparseable response), the backend does **not** error: it falls back to an in-Java calculation over the reservations stored in the database (same hourly-occupancy formula — non-CANCELLED reservations active in each hour, averaged over the distinct history days, as a % of the location's total slots, capped at 100%; a flat 10% profile when there is no history) and still returns `200 OK` in the same response shape. The prediction endpoint therefore has no `503` case, and all other endpoints are unaffected either way. The Python service URL is configurable via the `prediction.service.url` property / `PREDICTION_SERVICE_URL` env var (default `http://localhost:8000`).

---

## Endpoint Summary

| # | Method | Path | Role |
|---|---|---|---|
| 1 | POST | `/api/auth/register` | Public |
| 2 | POST | `/api/auth/login` | Public |
| 3 | GET | `/api/auth/me` | USER, ADMIN |
| 4 | GET | `/api/locations` | USER, ADMIN |
| 5 | GET | `/api/locations/{id}` | USER, ADMIN |
| 6 | POST | `/api/locations` | ADMIN |
| 7 | PUT | `/api/locations/{id}` | ADMIN |
| 8 | DELETE | `/api/locations/{id}` | ADMIN |
| 9 | GET | `/api/locations/{locationId}/slots` | USER, ADMIN |
| 10 | POST | `/api/locations/{locationId}/slots` | ADMIN |
| 11 | GET | `/api/slots/{id}` | USER, ADMIN |
| 12 | GET | `/api/slots/availability` | USER, ADMIN |
| 13 | PUT | `/api/slots/{id}` | ADMIN |
| 14 | DELETE | `/api/slots/{id}` | ADMIN |
| 15 | GET | `/api/vehicles/my` | USER |
| 16 | POST | `/api/vehicles` | USER |
| 17 | GET | `/api/vehicles/{id}` | USER (owner), ADMIN |
| 18 | PUT | `/api/vehicles/{id}` | USER (owner) |
| 19 | DELETE | `/api/vehicles/{id}` | USER (owner) |
| 20 | POST | `/api/reservations` | USER |
| 21 | GET | `/api/reservations/my` | USER |
| 22 | GET | `/api/reservations/{id}` | USER (owner), ADMIN |
| 23 | POST | `/api/reservations/{id}/cancel` | USER (owner), ADMIN |
| 24 | POST | `/api/reservations/{id}/entry` | USER (owner), ADMIN |
| 25 | POST | `/api/reservations/{id}/exit` | USER (owner), ADMIN |
| 26 | GET | `/api/reservations` | ADMIN |
| 27 | GET | `/api/admin/dashboard` | ADMIN |
| 28 | GET | `/api/predictions/occupancy` | USER, ADMIN |
