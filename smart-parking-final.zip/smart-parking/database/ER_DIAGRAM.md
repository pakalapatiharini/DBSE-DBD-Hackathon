# ER Diagram — Smart Parking Management System

This diagram matches `database/schema.sql` **exactly** — same tables, same columns, same types, same keys. If the schema changes, this file must change with it.

```mermaid
erDiagram
    users {
        BIGINT id PK
        VARCHAR full_name
        VARCHAR email UK
        VARCHAR password_hash
        VARCHAR phone
        ENUM role "USER, ADMIN"
        DATETIME created_at
        DATETIME updated_at
    }

    parking_locations {
        BIGINT id PK
        VARCHAR name
        VARCHAR address
        VARCHAR city
        DECIMAL hourly_rate
        TINYINT is_active
        DATETIME created_at
        DATETIME updated_at
    }

    parking_slots {
        BIGINT id PK
        BIGINT location_id FK
        VARCHAR slot_code UK "unique with location_id"
        ENUM vehicle_type "TWO_WHEELER, FOUR_WHEELER, EV, ACCESSIBLE, GENERAL"
        TINYINT is_active
        DATETIME created_at
        DATETIME updated_at
    }

    vehicles {
        BIGINT id PK
        BIGINT user_id FK
        VARCHAR license_plate UK
        ENUM vehicle_type "TWO_WHEELER, FOUR_WHEELER, EV, ACCESSIBLE, GENERAL"
        VARCHAR model
        VARCHAR color
        DATETIME created_at
        DATETIME updated_at
    }

    reservations {
        BIGINT id PK
        BIGINT user_id FK
        BIGINT vehicle_id FK
        BIGINT slot_id FK
        DATETIME start_time
        DATETIME end_time
        ENUM status "RESERVED, OCCUPIED, COMPLETED, CANCELLED"
        DECIMAL fee_amount
        DATETIME entry_time
        DATETIME exit_time
        DATETIME created_at
        DATETIME updated_at
    }

    parking_locations ||--o{ parking_slots : "has (location_id, ON DELETE CASCADE)"
    users ||--o{ vehicles : "owns (user_id, ON DELETE CASCADE)"
    users ||--o{ reservations : "makes (user_id, ON DELETE RESTRICT)"
    vehicles ||--o{ reservations : "booked in (vehicle_id, ON DELETE RESTRICT)"
    parking_slots ||--o{ reservations : "booked by (slot_id, ON DELETE RESTRICT)"
```

## Relationships

| Relationship | Via | Cardinality | Delete behaviour |
|---|---|---|---|
| `parking_locations` → `parking_slots` | `parking_slots.location_id` | One location has many slots | `ON DELETE CASCADE` — deleting a location deletes its slots (blocked in practice if any slot has reservations, because of the RESTRICT below) |
| `users` → `vehicles` | `vehicles.user_id` | One user owns many vehicles | `ON DELETE CASCADE` |
| `users` → `reservations` | `reservations.user_id` | One user makes many reservations | `ON DELETE RESTRICT` — reservation history is preserved |
| `vehicles` → `reservations` | `reservations.vehicle_id` | One vehicle appears in many reservations | `ON DELETE RESTRICT` |
| `parking_slots` → `reservations` | `reservations.slot_id` | One slot appears in many reservations | `ON DELETE RESTRICT` |

## Deliberate design points

- **No status column on `parking_slots`.** A slot's live status (AVAILABLE / RESERVED / OCCUPIED) is derived from `reservations` — see `docs/ARCHITECTURE.md` §4. `reservations.status` is the only stored status.
- **No `location_id` on `reservations`.** A reservation's location is always reached through `reservations.slot_id → parking_slots.location_id`. The API's reservation object exposes it as a read-only convenience field only.
- **Unique constraints:** `users.email`, `vehicles.license_plate`, and (`parking_slots.location_id`, `parking_slots.slot_code`).
- **Key index:** `idx_reservations_slot_time (slot_id, start_time, end_time)` supports the double-booking overlap check and live-status derivation. Other indexes: `idx_reservations_slot_status`, `idx_reservations_user_created`, `idx_reservations_status_start`, `idx_reservations_vehicle`, `idx_parking_slots_location_active`, `idx_vehicles_user`.
- **Checks:** `reservations.end_time > reservations.start_time`; `parking_locations.hourly_rate >= 0`; `reservations.fee_amount >= 0` when present.
