package com.smartparking.controller;

import com.smartparking.dto.ReservationDtos;
import com.smartparking.model.ReservationStatus;
import com.smartparking.service.ReservationService;
import jakarta.validation.Valid;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/reservations")
public class ReservationController {

    private final ReservationService reservationService;

    public ReservationController(ReservationService reservationService) {
        this.reservationService = reservationService;
    }

    @PostMapping
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<ReservationDtos.ReservationResponse> create(@Valid @RequestBody ReservationDtos.ReservationRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(reservationService.create(req));
    }

    @GetMapping("/my")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<List<ReservationDtos.ReservationResponse>> my(
            @RequestParam(required = false) ReservationStatus status) {
        return ResponseEntity.ok(reservationService.myReservations(status));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ReservationDtos.ReservationResponse> get(@PathVariable Long id) {
        return ResponseEntity.ok(reservationService.get(id));
    }

    @PostMapping("/{id}/cancel")
    public ResponseEntity<ReservationDtos.ReservationResponse> cancel(@PathVariable Long id) {
        return ResponseEntity.ok(reservationService.cancel(id));
    }

    @PostMapping("/{id}/entry")
    public ResponseEntity<ReservationDtos.ReservationResponse> entry(@PathVariable Long id) {
        return ResponseEntity.ok(reservationService.entry(id));
    }

    @PostMapping("/{id}/exit")
    public ResponseEntity<ReservationDtos.ReservationResponse> exit(@PathVariable Long id) {
        return ResponseEntity.ok(reservationService.exit(id));
    }

    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<ReservationDtos.ReservationResponse>> listForAdmin(
            @RequestParam(required = false) Long locationId,
            @RequestParam(required = false) ReservationStatus status,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        return ResponseEntity.ok(reservationService.listForAdmin(locationId, status, date));
    }
}
