package com.smartparking.dto;

import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class ReservationDtos {

    public record ReservationRequest(
            @NotNull(message = "vehicleId is required") Long vehicleId,
            @NotNull(message = "slotId is required") Long slotId,
            @NotNull(message = "startTime is required") LocalDateTime startTime,
            @NotNull(message = "endTime is required") LocalDateTime endTime
    ) {}

    public record ReservationResponse(
            Long id, Long userId, Long vehicleId, Long slotId, Long locationId,
            String licensePlate, String slotCode, String locationName,
            LocalDateTime startTime, LocalDateTime endTime,
            String status, BigDecimal feeAmount,
            LocalDateTime entryTime, LocalDateTime exitTime,
            LocalDateTime createdAt, LocalDateTime updatedAt
    ) {}
}
