package com.smartparking.service;

import com.smartparking.dto.ReservationDtos;
import com.smartparking.exception.ApiException;
import com.smartparking.model.ParkingSlot;
import com.smartparking.model.Reservation;
import com.smartparking.model.ReservationStatus;
import com.smartparking.model.User;
import com.smartparking.model.Vehicle;
import com.smartparking.repository.ReservationRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class ReservationService {

    /** Small grace so a booking starting "right now" is not rejected for clock skew. */
    private static final long START_GRACE_MINUTES = 5;
    private static final List<ReservationStatus> BLOCKING = List.of(ReservationStatus.RESERVED, ReservationStatus.OCCUPIED);

    private final ReservationRepository reservationRepository;
    private final VehicleService vehicleService;
    private final SlotService slotService;
    private final CurrentUserService currentUserService;

    public ReservationService(ReservationRepository reservationRepository,
                              VehicleService vehicleService,
                              SlotService slotService,
                              CurrentUserService currentUserService) {
        this.reservationRepository = reservationRepository;
        this.vehicleService = vehicleService;
        this.slotService = slotService;
        this.currentUserService = currentUserService;
    }

    public static ReservationDtos.ReservationResponse toResponse(Reservation r) {
        return new ReservationDtos.ReservationResponse(
                r.getId(),
                r.getUser().getId(),
                r.getVehicle().getId(),
                r.getSlot().getId(),
                r.getSlot().getLocation().getId(), // read-only convenience — no location_id column on reservations
                r.getVehicle().getLicensePlate(),
                r.getSlot().getSlotCode(),
                r.getSlot().getLocation().getName(),
                r.getStartTime(), r.getEndTime(),
                r.getStatus().name(),
                r.getFeeAmount(),
                r.getEntryTime(), r.getExitTime(),
                r.getCreatedAt(), r.getUpdatedAt());
    }

    /** fee = ceil hours (min 1) x hourly_rate, snapshotted at booking time. */
    public static BigDecimal computeFee(LocalDateTime start, LocalDateTime end, BigDecimal hourlyRate) {
        long minutes = Duration.between(start, end).toMinutes();
        long billableHours = Math.max(1L, (long) Math.ceil(minutes / 60.0));
        return hourlyRate.multiply(BigDecimal.valueOf(billableHours)).setScale(2, RoundingMode.HALF_UP);
    }

    @Transactional
    public ReservationDtos.ReservationResponse create(ReservationDtos.ReservationRequest req) {
        User current = currentUserService.getCurrentUser();

        if (!req.endTime().isAfter(req.startTime())) {
            throw ApiException.badRequest("endTime must be after startTime");
        }
        if (req.startTime().isBefore(LocalDateTime.now().minusMinutes(START_GRACE_MINUTES))) {
            throw ApiException.badRequest("startTime cannot be in the past");
        }

        Vehicle vehicle = vehicleService.findOrThrow(req.vehicleId());
        if (!vehicle.getUser().getId().equals(current.getId())) {
            throw ApiException.forbidden("Vehicle does not belong to the current user");
        }

        ParkingSlot slot = slotService.findOrThrow(req.slotId());
        if (Boolean.FALSE.equals(slot.getIsActive())) {
            throw ApiException.conflict("Slot " + slot.getSlotCode() + " is inactive");
        }

        // TRANSACTIONAL overlap check + insert (this method is @Transactional):
        // reject if a RESERVED/OCCUPIED reservation for the same slot overlaps [start, end).
        if (reservationRepository.existsOverlapping(slot.getId(), BLOCKING, req.startTime(), req.endTime())) {
            throw ApiException.conflict("Slot " + slot.getSlotCode()
                    + " is already booked for the selected time window");
        }

        BigDecimal fee = computeFee(req.startTime(), req.endTime(), slot.getLocation().getHourlyRate());
        Reservation r = new Reservation(current, vehicle, slot, req.startTime(), req.endTime(),
                ReservationStatus.RESERVED, fee);
        return toResponse(reservationRepository.save(r));
    }

    @Transactional(readOnly = true)
    public List<ReservationDtos.ReservationResponse> myReservations(ReservationStatus status) {
        User current = currentUserService.getCurrentUser();
        List<Reservation> list = status == null
                ? reservationRepository.findByUserIdOrderByCreatedAtDesc(current.getId())
                : reservationRepository.findByUserIdAndStatusOrderByCreatedAtDesc(current.getId(), status);
        return list.stream().map(ReservationService::toResponse).toList();
    }

    @Transactional(readOnly = true)
    public ReservationDtos.ReservationResponse get(Long id) {
        return toResponse(findOwnedOrAdminOrThrow(id));
    }

    @Transactional(readOnly = true)
    public List<ReservationDtos.ReservationResponse> listForAdmin(Long locationId, ReservationStatus status, LocalDate date) {
        LocalDateTime dayStart = date == null ? null : date.atStartOfDay();
        LocalDateTime dayEnd = date == null ? null : date.plusDays(1).atStartOfDay();
        return reservationRepository.findForAdmin(locationId, status, dayStart, dayEnd).stream()
                .map(ReservationService::toResponse).toList();
    }

    private Reservation findOwnedOrAdminOrThrow(Long id) {
        Reservation r = reservationRepository.findById(id)
                .orElseThrow(() -> ApiException.notFound("Reservation not found: " + id));
        User current = currentUserService.getCurrentUser();
        if (!r.getUser().getId().equals(current.getId()) && !currentUserService.isAdmin(current)) {
            throw ApiException.forbidden("Reservation does not belong to the current user");
        }
        return r;
    }

    @Transactional
    public ReservationDtos.ReservationResponse cancel(Long id) {
        Reservation r = findOwnedOrAdminOrThrow(id);
        if (r.getStatus() != ReservationStatus.RESERVED) {
            throw ApiException.conflict("Only a RESERVED reservation can be cancelled (current status: " + r.getStatus() + ")");
        }
        r.setStatus(ReservationStatus.CANCELLED);
        return toResponse(reservationRepository.save(r));
    }

    @Transactional
    public ReservationDtos.ReservationResponse entry(Long id) {
        Reservation r = findOwnedOrAdminOrThrow(id);
        if (r.getStatus() != ReservationStatus.RESERVED) {
            throw ApiException.conflict("Entry is only allowed from RESERVED (current status: " + r.getStatus() + ")");
        }
        r.setStatus(ReservationStatus.OCCUPIED);
        r.setEntryTime(LocalDateTime.now());
        return toResponse(reservationRepository.save(r));
    }

    @Transactional
    public ReservationDtos.ReservationResponse exit(Long id) {
        Reservation r = findOwnedOrAdminOrThrow(id);
        if (r.getStatus() != ReservationStatus.OCCUPIED) {
            throw ApiException.conflict("Exit is only allowed from OCCUPIED (current status: " + r.getStatus() + ")");
        }
        r.setStatus(ReservationStatus.COMPLETED);
        r.setExitTime(LocalDateTime.now());
        // Fee stays based on the booked window (finalised here, unchanged in the MVP — ARCHITECTURE.md §3).
        if (r.getFeeAmount() == null) {
            r.setFeeAmount(computeFee(r.getStartTime(), r.getEndTime(), r.getSlot().getLocation().getHourlyRate()));
        }
        return toResponse(reservationRepository.save(r));
    }
}
