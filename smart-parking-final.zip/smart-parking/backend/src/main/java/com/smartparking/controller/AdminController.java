package com.smartparking.controller;

import com.smartparking.dto.DashboardDtos;
import com.smartparking.service.DashboardService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/admin")
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {

    private final DashboardService dashboardService;

    public AdminController(DashboardService dashboardService) { this.dashboardService = dashboardService; }

    @GetMapping("/dashboard")
    public ResponseEntity<DashboardDtos.DashboardResponse> dashboard() {
        return ResponseEntity.ok(dashboardService.dashboard());
    }
}
